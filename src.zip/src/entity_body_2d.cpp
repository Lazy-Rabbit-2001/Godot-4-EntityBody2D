﻿#include "entity_body_2d.h"

#include "mathorm.h"

#include <godot_cpp/variant/utility_functions.hpp>


void EntityBody2D::_bind_methods() {
    // Register signals
    ADD_SIGNAL(MethodInfo("collided_wall", PropertyInfo(Variant::OBJECT, "collision_info")));
    ADD_SIGNAL(MethodInfo("collided_ceiling", PropertyInfo(Variant::OBJECT, "collision_info")));
    ADD_SIGNAL(MethodInfo("collided_floor", PropertyInfo(Variant::OBJECT, "collision_info")));

    // Register properties
    // Vector2 motion
    ClassDB::bind_method(D_METHOD("get_motion"), &EntityBody2D::get_motion);
    ClassDB::bind_method(D_METHOD("set_motion", "p_motion"), &EntityBody2D::set_motion);
    ClassDB::add_property(
        "EntityBody2D", PropertyInfo(Variant::VECTOR2, "motion"), 
        "set_motion", "get_motion"
    );
    ADD_GROUP("Gravity", "");
    // Vector2 gravity_direction
    ClassDB::bind_method(D_METHOD("get_gravity_direction"), &EntityBody2D::get_gravity_direction);
    ClassDB::bind_method(D_METHOD("set_gravity_direction", "p_gravity_direction"), &EntityBody2D::set_gravity_direction);
    ClassDB::add_property(
        "EntityBody2D", PropertyInfo(Variant::VECTOR2, "gravity_direction"), 
        "set_gravity_direction", "get_gravity_direction"
    );
    // double gravity
    ClassDB::bind_method(D_METHOD("get_gravity"), &EntityBody2D::get_gravity);
    ClassDB::bind_method(D_METHOD("set_gravity", "p_gravity"), &EntityBody2D::set_gravity);
    ClassDB::add_property(
        "EntityBody2D", PropertyInfo(Variant::FLOAT, "gravity", PROPERTY_HINT_RANGE, "0, 1, 0.001, or_less, or_greater, hide_slider, suffix:px/s^2"),
        "set_gravity", "get_gravity"
    );
    // double max_falling_speed
    ClassDB::bind_method(D_METHOD("get_max_falling_speed"), &EntityBody2D::get_max_falling_speed);
    ClassDB::bind_method(D_METHOD("set_max_falling_speed", "p_max_falling_speed"), &EntityBody2D::set_max_falling_speed);
    ClassDB::add_property(
        "EntityBody2D", PropertyInfo(Variant::FLOAT, "max_falling_speed", PROPERTY_HINT_RANGE, "0, 1, 0.001, or_greater, hide_slider, suffix:px/s"),
        "set_max_falling_speed", "get_max_falling_speed"
    );

    // Register methods
    ClassDB::bind_method(D_METHOD("get_real_up_direction"), &EntityBody2D::get_real_up_direction);
    ClassDB::bind_method(D_METHOD("move_and_slide", "is_gravity_direction_rotated", "use_real_velocity"), &EntityBody2D::move_and_slide, true, false);
    ClassDB::bind_method(D_METHOD("accelerate_x", "acceleration", "to"), &EntityBody2D::accelerate_x);
    ClassDB::bind_method(D_METHOD("accelerate_y", "acceleration", "to"), &EntityBody2D::accelerate_y);
    ClassDB::bind_method(D_METHOD("accelerate", "acceleration", "to"), &EntityBody2D::accelerate);
    ClassDB::bind_method(D_METHOD("use_friction", "miu"), &EntityBody2D::use_friction);
    ClassDB::bind_method(D_METHOD("jump", "jumping_speed", "is_accumulating_mode"), &EntityBody2D::jump, true);
}

// Constructor and Destructor
EntityBody2D::EntityBody2D() {
    // Properties' intialization
    gravity_direction = Vector2(0, 1);
    max_falling_speed = 1500;
}

EntityBody2D::~EntityBody2D() {}

// Methods
bool EntityBody2D::move_and_slide(bool is_gravity_direction_rotated, bool use_real_velocity) {
    bool ret = false;
    
    Vector2 up_direction = get_up_direction();
    _real_up_direction = up_direction.rotated(get_global_rotation());
    set_up_direction(_real_up_direction);
    

    if (is_gravity_direction_rotated) {
        gravity_direction = -_real_up_direction;
    }


    Vector2 velocity = get_velocity();

    bool on_floor = is_on_floor();
    bool is_slopable = !is_floor_stop_on_slope_enabled();
    bool is_slope_steel = !UtilityFunctions::is_zero_approx(get_floor_angle(_real_up_direction));
    bool is_able_to_slope_down = on_floor && is_slopable && is_slope_steel;

    if (!on_floor || is_able_to_slope_down) {
        // Falling
        Vector2 velocity_falling = velocity + gravity_direction * gravity * float(get_physics_process_delta_time());
        
        if (max_falling_speed > 0) {
            velocity_falling = Vec2D::get_projection_limit(velocity_falling, gravity_direction, max_falling_speed);
        }

        if (!is_floor_constant_speed_enabled()) {
            velocity_falling = velocity_falling.slide(get_floor_normal());
        }

        set_velocity(velocity_falling);
    }
        
    ret = CharacterBody2D::move_and_slide();
    if (!use_real_velocity) {
        set_velocity(get_real_velocity());
    }

    set_up_direction(up_direction);

    // Signals emission
    if (is_on_wall()) {
        emit_signal("collided_wall", get_last_slide_collision());
    }
    if (is_on_ceiling()) {
        emit_signal("collided_ceiling", get_last_slide_collision());
    }
    if (is_on_floor()) {
        emit_signal("collided_floor", get_last_slide_collision());
    }

    return ret;
}

void EntityBody2D::accelerate_x(double acceleration, double to) {
    Vector2 velocity = get_velocity();
    set_velocity(velocity + Vector2(float(godot::Math::move_toward(double(velocity.x), to, godot::Math::abs(acceleration) * get_physics_process_delta_time())), 0));
}

void EntityBody2D::accelerate_y(double acceleration, double to) {
    Vector2 velocity = get_velocity();
    set_velocity(velocity + Vector2(0, float(godot::Math::move_toward(double(velocity.y), to, godot::Math::abs(acceleration) * get_physics_process_delta_time()))));
}

void EntityBody2D::accelerate(double acceleration, Vector2 to) {
    Vector2 velocity = get_velocity();
    set_velocity(velocity.move_toward(to, float(acceleration * get_physics_process_delta_time())));
}

void EntityBody2D::use_friction(double miu) {
    Vector2 velocity = get_velocity();
    Vector2 slide_vel = velocity.slide(get_up_direction());
    Vector2 friction_affected_vel = slide_vel.lerp(Vector2(0, 0), float(miu * get_physics_process_delta_time()));
    Vector2 result = velocity - (slide_vel - friction_affected_vel);
    set_velocity(result);
}

void EntityBody2D::jump(double jumping_speed, bool is_accumulating_mode) {
    Vector2 velocity = get_velocity();
    Vector2 up_direction = get_real_up_direction();
    float j_speed = UtilityFunctions::absf(jumping_speed);
    
    if (is_accumulating_mode) {
        set_velocity(velocity + up_direction * j_speed);
    } 
    else {
        Vector2 jumping_velocity = velocity - velocity.project(gravity_direction);
        set_velocity(jumping_velocity + up_direction * j_speed);
    }
    
}

// Properties' Setters and Getters
Vector2 EntityBody2D::get_real_up_direction() const {
    return _real_up_direction;
}

// Vector2 motion
void EntityBody2D::set_motion(Vector2 p_motion) {
    set_velocity(p_motion.rotated(get_global_rotation()));
}

Vector2 EntityBody2D::get_motion() const {
    return get_velocity().rotated(-get_global_rotation());
}

// Vecotr2 gravity_direction
void EntityBody2D::set_gravity_direction(Vector2 p_gravity_direction) {
    gravity_direction = p_gravity_direction.normalized();
}

Vector2 EntityBody2D::get_gravity_direction() const {
    return gravity_direction;
}

// double gravity
void EntityBody2D::set_gravity(double p_gravity) {
    gravity = p_gravity;
}

double EntityBody2D::get_gravity() const {
    return gravity;
}

// double max_falling_speed
void EntityBody2D::set_max_falling_speed(double p_max_falling_speed) {
    max_falling_speed = p_max_falling_speed;
}

double EntityBody2D::get_max_falling_speed() const {
    return max_falling_speed;
}